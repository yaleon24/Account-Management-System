/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;



public class Recursion {
    public int array17(int[] nums, int index) {
  if(index>=nums.length)
      return 0;
  if(nums[index]==17)
      return 1+array17(nums,index+1);
  return array17(nums,index+1);        
}
    
    public static void main(String[] args) {
        final int NUM = 5;
        int [] arr = new int[NUM];
        Scanner scanner = new Scanner(System.in);
        for(int i = 0; i < NUM; i++){
           System.out.println("Enter a number:");
            while(!scanner.hasNextInt()){
                scanner.next();
            }
            arr[i] = scanner.nextInt();
           //this is a hint for your AccountManagement program!  Use this to only allow numbers entered.
           
        }
        System.out.println("Enter an index starting point:");
            while(!scanner.hasNextInt()){
                scanner.next();
            }
        int index = scanner.nextInt();
        
        System.out.println(new Recursion().array17(arr, index));
        

    }
}
