/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Yasmany
 */

class Account{

    
}
public class AccountMangement {
 private  int id;
   private double balance;
   private String name;

    public AccountMangement(int id, double balance, String name) {
        this.id = id;
        this.balance = balance;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", balance=" + balance + ", name=" + name + '}';
    }

    public static void main(String[] args) {

        AccountMangement acc1 = new AccountMangement(1,400,"Homer Simpson" );
        AccountMangement acc2 = new AccountMangement(2,325,"George Jetson" );
        AccountMangement acc3 = new AccountMangement(3,1050,"Fred Flintstone" );
        AccountMangement acc4 = new AccountMangement(4,60,"Peter Griffin" );
        AccountMangement acc5 = new AccountMangement(5,200,"  Professor Utonium" );
       ArrayList<Account> arraylist=new ArrayList<Account>();
          
        Scanner scan=new Scanner(System.in);
        while(true){
        System.out.println("Enter an id: -1 to end the program.");
         while(!scan.hasNextInt()){
           scan.next();
          }
        int id=scan.nextInt(); 
          while(id<1 && id>5){
              
        System.out.println("Invalid id entered.");
        
         }
         if(id==-1){
             break;
         }
       
         int choice;
         do{
        System.out.println("Main menu:");
        System.out.println("1: Check balance");
        System.out.println("2: Withdraw");
        System.out.println("3: Deposit");
        System.out.println("4: Exit");
        System.out.println("Enter a choice:");
        choice=scan.nextInt();
         
         if(choice==1){   
           if(id==1){   
        System.out.println("The balance is "+acc1.balance );
           }
           else if(id==2){
               System.out.println("The balance is "+acc2.balance );  
           }
            else if(id==3){
               System.out.println("The balance is "+acc3.balance );  
           }
            else if(id==4){
               System.out.println("The balance is "+acc4.balance );  
           }
            else if(id==5){
               System.out.println("The balance is "+acc5.balance );  
           }
         }
          else if(choice==2){
             
        System.out.println("Enter an amount to withdraw:");
           while(!scan.hasNextDouble()){
           scan.next();
          }
        double withdraw = scan.nextDouble();
            
             acc1.balance = (int) (400-withdraw);
             acc2.balance = (int) (325-withdraw);
             acc3.balance = (int) (1050-withdraw);
             acc4.balance = (int) (60-withdraw);
             acc5.balance = (int) (200-withdraw);
         }
       
          else if(choice==3){
            
        System.out.println("Enter an amount to deposit:");
         while(!scan.hasNextDouble()){
           scan.next();
          }
            double deposit = scan.nextDouble();
             acc1.balance = (int) (400+deposit);
             acc2.balance = (int) (325+deposit);
             acc3.balance = (int) (1050+deposit);
             acc4.balance = (int) (60+deposit);
             acc5.balance = (int) (200+deposit);
         }
        
         if(choice==4){
             break;
         }
          }while(choice >0&& choice <5);
         }
        }        
            
    

}
    

